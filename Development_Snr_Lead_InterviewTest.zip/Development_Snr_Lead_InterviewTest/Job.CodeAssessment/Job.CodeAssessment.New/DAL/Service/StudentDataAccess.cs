﻿using Job.CodeAssessment.New.DbContext.IService;
using Job.CodeAssessment.New.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Job.CodeAssessment.New.DbContext.Service
{
    public class StudentDataAccess : IStudentDataAccess
    {
        public StudentResponse LoadStudent(int studentId)
        {
            // retrieve student from 3rd party webservice
            return new StudentResponse();
        }
    }
}
