﻿using Job.CodeAssessment.New.DbContext.IService;
using Job.CodeAssessment.New.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Job.CodeAssessment.New.DbContext.Service
{
    public class FailoverStudentDataAccess : IFailoverStudentDataAccess
    {
        public StudentResponse GetStudentById(int id)
        {
            // retrieve student from database
            return new StudentResponse();
        }
    }
}
