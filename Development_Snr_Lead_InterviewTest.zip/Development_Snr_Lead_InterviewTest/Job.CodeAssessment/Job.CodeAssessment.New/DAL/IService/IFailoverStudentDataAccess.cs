﻿using Job.CodeAssessment.New.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Job.CodeAssessment.New.DbContext.IService
{
    public interface IFailoverStudentDataAccess
    {
        StudentResponse GetStudentById(int id);
    }
}
