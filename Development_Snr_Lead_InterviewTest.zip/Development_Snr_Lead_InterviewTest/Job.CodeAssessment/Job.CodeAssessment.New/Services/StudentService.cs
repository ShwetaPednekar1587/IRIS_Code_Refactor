﻿using Job.CodeAssessment.New.DbContext.IService;
using Job.CodeAssessment.New.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace Job.CodeAssessment.New.Services
{
    public class StudentService : IStudentService
    {
        public readonly IArchivedDataService _archivedDataService;
        public readonly IFailoverRepository _failoverRepository;
        public readonly IFailoverStudentDataAccess _failoverStudentDataAccess;
        public readonly IStudentDataAccess _studentDataAccess;
        public StudentService(IArchivedDataService archivedDataService,
            IFailoverRepository failoverRepository,
            IFailoverStudentDataAccess failoverStudentDataAccess,
            IStudentDataAccess studentDataAccess)
        {
            _archivedDataService = archivedDataService;
            _failoverRepository = failoverRepository;
            _failoverStudentDataAccess = failoverStudentDataAccess;
            _studentDataAccess = studentDataAccess;
        }
        public Student GetStudent(int studentId, bool isStudentArchived)
        {
            Student archivedStudent = null;
            try
            {
                if (isStudentArchived)
                {
                    return _archivedDataService.GetArchivedStudent(studentId);
                }
                else
                {
                    var failoverEntries = _failoverRepository.GetFailOverEntries();
                    var failedRequests = 0;
                    StudentResponse studentResponse = null;
                    Student student = null;

                    foreach (var failoverEntry in failoverEntries)
                    {
                        if (failoverEntry.DateTime > DateTime.Now.AddMinutes(-10))
                        {
                            failedRequests++;
                        }
                    }
                    if (failedRequests > 100 && (ConfigurationManager.AppSettings["IsFailoverModeEnabled"] == "true" || ConfigurationManager.AppSettings["IsFailoverModeEnabled"] == "True"))
                    {
                        studentResponse = _failoverStudentDataAccess.GetStudentById(studentId);
                    }
                    else
                    {
                        studentResponse = _studentDataAccess.LoadStudent(studentId);
                    }

                    if (studentResponse.IsArchived)
                    {                      
                        student = _archivedDataService.GetArchivedStudent(studentId);
                    }
                    else
                    {
                        student = studentResponse.Student;
                    }
                    return student;
                }                
            }
            catch (Exception ex)
            {
                //log exception
                //Handle exception
            }
            return archivedStudent;
        }
    }
}
