﻿namespace Job.CodeAssessment
{
    public class ArchivedDataService
    {
        public Student GetArchivedStudent(int studentId)
        {
            // retrieve student from archive data service
            return new Student();
        }
    }
}