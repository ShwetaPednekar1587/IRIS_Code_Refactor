﻿using System;

namespace Job.CodeAssessment
{
    public class FailoverEntry
    {
        public DateTime DateTime { get; set; }
    }
}