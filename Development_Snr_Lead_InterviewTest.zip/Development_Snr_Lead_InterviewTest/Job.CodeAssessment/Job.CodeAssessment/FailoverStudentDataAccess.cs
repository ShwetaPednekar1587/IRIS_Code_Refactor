﻿namespace Job.CodeAssessment
{
    public class FailoverStudentDataAccess
    {
        public static StudentResponse GetStudentById(int id)
        {
            // retrieve student from database
            return new StudentResponse();
        }
    }
}