﻿namespace Job.CodeAssessment
{
    public class StudentResponse
    {
        public bool IsArchived { get; set; }

        public Student Student { get; set; }
    }
}