﻿namespace Job.CodeAssessment
{
    public class StudentDataAccess
    {
        public StudentResponse LoadStudent(int studentId)
        {
            // retrieve student from 3rd party webservice
            return new StudentResponse();
        }
    }
}